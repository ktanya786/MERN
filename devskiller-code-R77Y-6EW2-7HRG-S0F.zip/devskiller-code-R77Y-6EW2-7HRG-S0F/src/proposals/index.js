import ProposalDetailsPage from "./ProposalDetailsPage";
import ProposalListPage from "./ProposalListPage";

export {
    ProposalDetailsPage,
    ProposalListPage,
};
